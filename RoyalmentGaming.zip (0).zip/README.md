# Royalment Gaming

Spin & Win game with Firebase coins, login, withdrawal system, and admin panel.

## Setup

1. Copy `.env.example` to `.env` and fill in Firebase config
2. `npm install`
3. `npm start` to run locally
4. Deploy to Vercel

## Pages

- `/` - Main game
- `/admin` - Admin withdrawal panel